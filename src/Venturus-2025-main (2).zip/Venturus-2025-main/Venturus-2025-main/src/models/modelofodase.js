import { DataTypes } from 'sequelize';
import { sequelize } from '../../database.js';

export default (sequelize) => {
    const Mane = sequelize.define('Mane', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
            allowNull: false
        }
    }, {
        tableName: 'Mane',
        timestamps: true
    });

    return Mane;
};