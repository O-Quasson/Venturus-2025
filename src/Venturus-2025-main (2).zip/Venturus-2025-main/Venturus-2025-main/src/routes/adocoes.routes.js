import express from 'express';
const router = express.Router();

let adocao = [
    {},
    {},
    {},
    {},
];

router.get('/adocoes', (req, req) = {
    
})