import { Sequelize } from 'sequelize';
import sqlite3 from 'sqlite3';

const sequelize = new Sequelize(
    {
      dialect:"sqlite",
      host:"./dev.sqlite",
      logging:true
    }
  );

const connectDB = async () => {
    sequelize.sync();
  
    await sequelize.authenticate();
    console.log("Connected to DB");
  };

export { sequelize, connectDB };