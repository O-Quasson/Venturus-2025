import express from 'express';
import { connectDB } from "./database.js";
import Usuario from "./src/models/Usuario.js";
import Mane from "./src/models/modelofodase.js"

const app = express();
const port = 3000;
connectDB()


app.use(express.json());

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});